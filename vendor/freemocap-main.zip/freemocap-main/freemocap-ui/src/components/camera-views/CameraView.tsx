import React, {memo, useEffect, useMemo, useRef} from 'react';
import {useServer} from '@/services/server/ServerContextProvider';
import {backendColor, frontendColor} from '@/components/framerate-viewer/FrameRateViewer';
import {useZoomTransform} from '@/hooks/useZoomTransform';

interface CameraViewProps {
    cameraIndex: number;
    cameraId: string;
    scale?: number;
    maxWidth?: boolean;
}

/** How often (ms) to update the FPS display text. 4Hz is plenty for a number readout. */
const FPS_UPDATE_INTERVAL_MS = 1000;

/**
 * CameraView component - renders a canvas for a single camera feed.
 * Wrapped in memo to prevent re-renders when props haven't changed.
 * FPS display uses direct DOM manipulation via a low-frequency setInterval
 * instead of a per-component requestAnimationFrame loop.
 *
 * Zoom is provided by useZoomTransform (scroll-to-zoom, drag-to-pan, pinch-to-zoom).
 */
export const CameraView: React.FC<CameraViewProps> = memo(({cameraIndex, cameraId, scale, maxWidth }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const displayFpsRef = useRef<HTMLSpanElement>(null);
    const serverFpsRef = useRef<HTMLSpanElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const { setCanvasForCamera, getFps, getServerFps } = useServer();

    const { zoomWrapperStyle, cursor, containerHandlers } = useZoomTransform(containerRef);

    useEffect(() => {
        const canvas = canvasRef.current;

        if (canvas && cameraId) {
            setCanvasForCamera(cameraId, canvas);
        }
    }, [cameraId, setCanvasForCamera]);

    // Update FPS displays at a low frequency via setInterval
    useEffect(() => {
        const updateFps = () => {
            const displayFps = getFps(cameraId);
            if (displayFpsRef.current) {
                displayFpsRef.current.textContent = displayFps !== null
                    ? `${displayFps.toFixed(1)}`
                    : '--';
            }
            const srvFps = getServerFps();
            if (serverFpsRef.current) {
                serverFpsRef.current.textContent = srvFps !== null
                    ? `${srvFps.toFixed(1)}`
                    : '--';
            }
        };

        const intervalId = setInterval(updateFps, FPS_UPDATE_INTERVAL_MS);
        return () => clearInterval(intervalId);
    }, [cameraId, getFps, getServerFps]);

    const canvasStyle = useMemo((): React.CSSProperties => {
        if (maxWidth) {
            return { width: '100%', height: '100%', objectFit: 'contain' };
        }
        if (scale !== undefined && scale !== 1.0) {
            return { width: `${scale * 100}%`, height: `${scale * 100}%`, objectFit: 'contain' };
        }
        return { width: '100%', height: '100%', objectFit: 'contain' };
    }, [scale, maxWidth]);

    return (
        <div
            ref={containerRef}
            className="w-full h-full flex flex-col items-center justify-center pos-rel overflow-hidden"
            style={{
                backgroundColor: '#000',
                cursor,
            }}
            {...containerHandlers}
        >
            <div style={zoomWrapperStyle}>
                <canvas
                    ref={canvasRef}
                    style={canvasStyle}
                />
            </div>
            <div
                className="pos-abs bottom-8 left-8 br-1"
                style={{
                    backgroundColor: 'rgba(0, 0, 0, 0.75)',
                    color: '#fff',
                    padding: '4px 8px',
                    fontSize: '12px',
                    fontFamily: 'monospace',
                    lineHeight: 1.4,
                }}
            >
                <div className="camera-stats flex" style={{ fontSize: '10px', marginTop: '2px', gap: '6px', whiteSpace: 'nowrap' }}>
                    <span style={{color:'#aaa'}}>#{cameraIndex} - {cameraId}</span>
                    <span style={{ color: frontendColor }}>
                        D:<span ref={displayFpsRef} style={{display: 'inline-block', minWidth: '5ch', textAlign: 'right'}}>--</span>
                    </span>
                    <span style={{ color: backendColor }}>
                        S:<span ref={serverFpsRef} style={{display: 'inline-block', minWidth: '5ch', textAlign: 'right'}}>--</span>
                    </span>
                    <span style={{ color: '#aaa' }}>fps</span>
                </div>
            </div>
        </div>
    );
}, (prevProps, nextProps) => {
    return prevProps.cameraId === nextProps.cameraId &&
        prevProps.scale === nextProps.scale &&
        prevProps.maxWidth === nextProps.maxWidth;
});

CameraView.displayName = 'CameraView';
