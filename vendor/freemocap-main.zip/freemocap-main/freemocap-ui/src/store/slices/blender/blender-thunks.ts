import {createAsyncThunk} from '@reduxjs/toolkit';
import {RootState} from '@/store/types';
import {serverUrls} from '@/services';
import {getDetailedErrorMessage} from '@/store/slices/thunk-helpers';
import {selectActiveRecordingFullPath} from '@/store/slices/active-recording/active-recording-slice';

interface DetectBlenderResult {
    blenderExePath: string | null;
    found: boolean;
    message?: string | null;
}

export const detectBlender = createAsyncThunk<
    DetectBlenderResult,
    void,
    { state: RootState; rejectValue: string }
>(
    'blender/detect',
    async (_, {rejectWithValue}) => {
        try {
            const response = await fetch(serverUrls.endpoints.blenderDetect);
            if (!response.ok) {
                return rejectWithValue(await getDetailedErrorMessage(response));
            }
            const data = await response.json();
            return {
                blenderExePath: data.blender_exe_path ?? null,
                found: !!data.found,
                message: data.message ?? null,
            };
        } catch (e) {
            return rejectWithValue(e instanceof Error ? e.message : 'Unknown error');
        }
    }
);

interface ExportBlenderResult {
    success: boolean;
    message?: string | null;
    blenderFilePath?: string | null;
}

export const exportRecordingToBlender = createAsyncThunk<
    ExportBlenderResult,
    { recordingFolderPath: string } | void,
    { state: RootState; rejectValue: string }
>(
    'blender/export',
    async (arg, {getState, rejectWithValue}) => {
        try {
            const state = getState();
            const blender = state.blender;
            const recordingFolderPath =
                (arg && arg.recordingFolderPath) ||
                selectActiveRecordingFullPath(state);

            if (!recordingFolderPath) {
                return rejectWithValue('No recording folder path available for Blender export');
            }

            const blenderExePath = blender.blenderExePath ?? blender.detectedBlenderExePath;

            const response = await fetch(serverUrls.endpoints.blenderExport, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    recordingFolderPath,
                    blenderExePath,
                    autoOpenBlendFile: blender.autoOpenBlendFile,
                    blenderExportConfig: state.mocap.config.blender_export,
                }),
            });

            if (!response.ok) {
                return rejectWithValue(await getDetailedErrorMessage(response));
            }
            const data = await response.json();
            return {
                success: !!data.success,
                message: data.message ?? null,
                blenderFilePath: data.blender_file_path ?? null,
            };
        } catch (e) {
            return rejectWithValue(e instanceof Error ? e.message : 'Unknown error');
        }
    }
);

interface OpenBlenderResult {
    success: boolean;
    message?: string | null;
    blendFilePath?: string | null;
}

export const openRecordingInBlender = createAsyncThunk<
    OpenBlenderResult,
    { recordingFolderPath: string } | void,
    { state: RootState; rejectValue: string }
>(
    'blender/open',
    async (arg, {getState, rejectWithValue}) => {
        try {
            const state = getState();
            const blender = state.blender;
            const recordingFolderPath =
                (arg && arg.recordingFolderPath) ||
                selectActiveRecordingFullPath(state);

            if (!recordingFolderPath) {
                return rejectWithValue('No recording folder path available to open in Blender');
            }

            const blenderExePath = blender.blenderExePath ?? blender.detectedBlenderExePath;

            const response = await fetch(serverUrls.endpoints.blenderOpen, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    recordingFolderPath,
                    blenderExePath,
                }),
            });

            if (!response.ok) {
                return rejectWithValue(await getDetailedErrorMessage(response));
            }
            const data = await response.json();
            return {
                success: !!data.success,
                message: data.message ?? null,
                blendFilePath: data.blend_file_path ?? null,
            };
        } catch (e) {
            return rejectWithValue(e instanceof Error ? e.message : 'Unknown error');
        }
    }
);
