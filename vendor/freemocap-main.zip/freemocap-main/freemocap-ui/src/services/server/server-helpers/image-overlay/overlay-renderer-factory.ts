// overlay-renderer-factory.ts
import {CharucoOverlayRenderer} from './charuco-overlay-renderer';
import {SkeletonObservation, SkeletonOverlayRenderer} from './skeleton-overlay-renderer';
import {BaseOverlayRenderer, ModelInfo} from "@/services/server/server-helpers/image-overlay/image-overlay-system";
import {CharucoObservation} from "@/services/server/server-helpers/image-overlay/charuco-types";
import {TrackedObjectDefinition} from "@/services/server/server-helpers/tracked-object-definition";

export type ObservationType = 'charuco_overlay' | 'mediapipe_overlay' | 'rtmpose_overlay' | 'skeleton_overlay';


/**
 * Factory for creating appropriate overlay renderers based on observation type
 */
export class OverlayRendererFactory {
    private static rendererCache: Map<ObservationType, BaseOverlayRenderer> = new Map();
    private static modelInfoCache: Map<string, ModelInfo> = new Map();

    /**
     * Set model info for a specific tracker type
     */
    public static setModelInfo(trackerName: string, modelInfo: ModelInfo): void {
        this.modelInfoCache.set(trackerName, modelInfo);

        // Update all renderers that might use this model info
        for (const [type, renderer] of this.rendererCache) {
            if (this.shouldUseModelInfo(type, trackerName)) {
                renderer.setModelInfo(modelInfo);
            }
        }
    }


    /**
     * Determine if a renderer type should use a specific model info
     */
    private static shouldUseModelInfo(
        rendererType: ObservationType,
        trackerName: string
    ): boolean {
        const mapping: Record<ObservationType, string[]> = {
            'charuco_overlay': ['CharucoTracker'],
            'mediapipe_overlay': ['MediapipeHolisticTracker', 'MediapipeTracker'],
            'rtmpose_overlay': ['RTMPoseTracker'],
            'skeleton_overlay': ['RTMPoseTracker', 'MediapipeHolisticTracker', 'MediapipeTracker'],
        };

        return mapping[rendererType]?.includes(trackerName) || false;
    }
}

/**
 * Manager for handling overlay rendering across multiple cameras.
 *
 * Composites both charuco and skeleton overlays sequentially onto each
 * frame: source → charuco → skeleton. Each renderer draws on top of
 * the previous result rather than clearing and redrawing from scratch.
 */
export class OverlayManager {
    private charucoRenderer: CharucoOverlayRenderer = new CharucoOverlayRenderer();
    private skeletonRenderer: SkeletonOverlayRenderer = new SkeletonOverlayRenderer();

    /**
     * Composite both overlay types onto a single frame, chained sequentially.
     * The charuco overlay is drawn first, then the skeleton overlay on top.
     */
    public async processFrame(
        cameraId: string,
        sourceBitmap: ImageBitmap,
        charucoObservation: CharucoObservation | null,
        skeletonObservation: SkeletonObservation | null,
    ): Promise<ImageBitmap> {
        let currentBitmap = sourceBitmap;

        if (charucoObservation) {
            currentBitmap = await this.charucoRenderer.compositeFrame(
                currentBitmap,
                charucoObservation,
            );
        }

        if (skeletonObservation) {
            currentBitmap = await this.skeletonRenderer.compositeFrame(
                currentBitmap,
                skeletonObservation,
            );
        }

        return currentBitmap;
    }

    /**
     * Set model info on both renderers
     */
    public setModelInfo(modelInfo: ModelInfo): void {
        this.charucoRenderer.setModelInfo(modelInfo);
        this.skeletonRenderer.setModelInfo(modelInfo);
    }

    /**
     * Push the active tracker schema into the skeleton renderer. Looks up the
     * schema by `tracker_id` that skeleton observations reference; falls back
     * to the first schema in the map if the exact id isn't present yet.
     */
    public setTrackerSchemas(
        schemas: Record<string, TrackedObjectDefinition>,
        activeTrackerId?: string,
    ): void {
        const keys = Object.keys(schemas);
        if (keys.length === 0) {
            this.skeletonRenderer.setSchema(null);
            return;
        }
        const id = activeTrackerId && schemas[activeTrackerId] ? activeTrackerId : keys[0];
        this.skeletonRenderer.setSchema(schemas[id]);
    }

    /**
     * Clear all renderers
     */
    public clearAll(): void {
        this.charucoRenderer.destroy();
        this.skeletonRenderer.destroy();
        this.charucoRenderer = new CharucoOverlayRenderer();
        this.skeletonRenderer = new SkeletonOverlayRenderer();
    }
}
