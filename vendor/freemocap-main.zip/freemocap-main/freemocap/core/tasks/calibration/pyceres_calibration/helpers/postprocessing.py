"""Post-processing transforms for calibrated cameras.

Pin camera 0 to origin, align charuco board as ground plane,
compute world-frame camera positions and orientations.
"""

import logging

import numpy as np
from numpy.typing import NDArray
from scipy.spatial.transform import Rotation

from freemocap.core.tasks.calibration.shared.camera_extrinsics import CameraExtrinsics
from freemocap.core.tasks.calibration.shared.camera_model import CameraModel
from freemocap.core.tasks.calibration.charuco_board.charuco_corners import CharucoCornersObservation
from skellytracker.core.detectors.keypoint_detectors.charuco import CharucoBoardDefinition
from freemocap.core.tasks.calibration.shared.camera_id_resolution import resolve_camera_id_or_raise
from freemocap.core.tasks.calibration.shared.groundplane_alignment import GroundPlaneResult, \
    apply_groundplane_to_cameras
from freemocap.core.tasks.calibration.shared.groundplane_math import estimate_board_groundplane

logger = logging.getLogger(__name__)


# =============================================================================
# PIN CAMERA TO ORIGIN
# =============================================================================


def pin_camera_to_origin(
    *,
    cameras: list[CameraModel],
    camera_id: str,
) -> list[CameraModel]:
    """Re-express all camera extrinsics relative to the specified camera.

    After this transform, the target camera has identity rotation and zero
    translation (it sits at the world origin looking along +Z).

    Args:
        cameras: List of camera models with extrinsics.
        camera_id: ID of the camera to place at the origin. Resolved against
            the camera list using the shared fallback ladder (exact id
            equality, then heuristic index match).

    Returns:
        New list of CameraModel with adjusted extrinsics.
    """
    candidate_ids = [cam.id for cam in cameras]
    resolved_id = resolve_camera_id_or_raise(
        camera_id, candidate_ids, context="pin_camera_to_origin",
    )
    ref_cam = next(cam for cam in cameras if cam.id == resolved_id)
    R0 = ref_cam.extrinsics.rotation_matrix
    t0 = ref_cam.extrinsics.translation

    result: list[CameraModel] = []
    for cam in cameras:
        R_i = cam.extrinsics.rotation_matrix
        t_i = cam.extrinsics.translation

        # New rotation: R_i_new = R_i @ R0^T
        R_new = R_i @ R0.T

        # New translation: t_new = t_i + R_i @ R0^T @ (-t0)
        t_new = t_i + R_i @ R0.T @ (-t0)

        # Convert to quaternion wxyz
        quat_xyzw = Rotation.from_matrix(R_new).as_quat()
        quat_wxyz = np.array(
            [quat_xyzw[3], quat_xyzw[0], quat_xyzw[1], quat_xyzw[2]],
            dtype=np.float64,
        )

        new_extrinsics = CameraExtrinsics(
            quaternion_wxyz=quat_wxyz,
            translation=t_new,
        )

        result.append(
            CameraModel(
                id=cam.id,
                image_size=cam.image_size,
                intrinsics=cam.intrinsics,
                extrinsics=new_extrinsics,
            )
        )

    logger.info(
        f"Pinned camera '{ref_cam.id}' to origin. "
        f"Adjusted {len(cameras)} camera extrinsics."
    )

    return result


# =============================================================================
# GROUND PLANE ALIGNMENT
# =============================================================================


def _triangulate_charuco_corners(
    *,
    cameras: list[CameraModel],
    all_observations: list[CharucoCornersObservation],
    board: CharucoBoardDefinition,
) -> NDArray[np.float64]:
    """Triangulate charuco corners into 3D for ground plane estimation.

    Uses DLT triangulation across all cameras for each frame, then stacks
    into (n_frames, n_corners, 3). Missing corners are filled with NaN.

    Returns:
        (n_frames, n_corners, 3) array of triangulated 3D positions.
    """
    # Group observations by frame
    cam_name_to_model = {cam.id: cam for cam in cameras}
    frame_groups: dict[int, dict[str, CharucoCornersObservation]] = {}
    for obs in all_observations:
        if obs.frame_index not in frame_groups:
            frame_groups[obs.frame_index] = {}
        frame_groups[obs.frame_index][obs.camera_name] = obs

    sorted_frames = sorted(frame_groups.keys())
    n_frames = len(sorted_frames)
    n_corners = board.n_corners

    result = np.full((n_frames, n_corners, 3), np.nan, dtype=np.float64)

    for fi, frame_idx in enumerate(sorted_frames):
        frame_obs = frame_groups[frame_idx]

        for corner_id in range(n_corners):
            # Collect 2D observations of this corner across cameras
            cam_observations: list[tuple[NDArray[np.float64], NDArray[np.float64]]] = []

            for cam_name, obs in frame_obs.items():
                cam = cam_name_to_model[cam_name]
                for c in obs.corners:
                    if c.corner_id == corner_id:
                        P = cam.projection_matrix
                        cam_observations.append((c.pixel_xy, P))
                        break

            if len(cam_observations) < 2:
                continue

            # DLT triangulation
            n_views = len(cam_observations)
            A = np.zeros((n_views * 2, 4), dtype=np.float64)
            for vi, (px, P) in enumerate(cam_observations):
                x, y = px
                A[vi * 2] = x * P[2] - P[0]
                A[vi * 2 + 1] = y * P[2] - P[1]

            _, _, vh = np.linalg.svd(A, full_matrices=False)
            pt_h = vh[-1]
            if abs(pt_h[3]) < 1e-10:
                continue
            result[fi, corner_id] = pt_h[:3] / pt_h[3]

    return result


def estimate_charuco_groundplane(
    *,
    cameras: list[CameraModel],
    board: CharucoBoardDefinition,
    all_observations: list[CharucoCornersObservation],
) -> GroundPlaneResult:
    """Estimate the ground plane from charuco board observations.

    Triangulates charuco corners, finds a stationary frame, and computes
    orthonormal basis vectors from the board corners.

    Args:
        cameras: Calibrated camera models.
        board: Board definition.
        all_observations: All frame observations for triangulation.

    Returns:
        GroundPlaneResult with origin at board corner 0 and basis from board edges.
    """
    logger.info("Estimating ground plane from charuco board...")

    charuco_3d = _triangulate_charuco_corners(
        cameras=cameras,
        all_observations=all_observations,
        board=board,
    )

    camera_centers = np.array(
        [
            -cam.extrinsics.rotation_matrix.T @ cam.extrinsics.translation
            for cam in cameras
        ]
    )

    rotation_matrix, origin = estimate_board_groundplane(
        charuco_3d,
        board_points=board.corner_positions_board_frame,
        camera_centers=camera_centers,
    )

    return GroundPlaneResult(
        origin=origin,
        rotation_matrix=rotation_matrix,
        method="charuco",
    )


def align_to_charuco_groundplane(
    *,
    cameras: list[CameraModel],
    board: CharucoBoardDefinition,
    all_observations: list[CharucoCornersObservation],
) -> tuple[list[CameraModel], GroundPlaneResult]:
    """Transform the world frame so the charuco board defines the ground plane.

    The charuco board's origin corner becomes the world origin, its X edge
    defines +X, and the board normal defines +Z (up).

    Args:
        cameras: Calibrated camera models.
        board: Board definition.
        all_observations: All frame observations for triangulation.

    Returns:
        Tuple of (camera models with adjusted extrinsics, ground plane result).
    """
    ground_plane = estimate_charuco_groundplane(
        cameras=cameras,
        board=board,
        all_observations=all_observations,
    )
    return apply_groundplane_to_cameras(cameras, ground_plane), ground_plane
