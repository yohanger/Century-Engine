from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from skellytracker.core import DetectionStageConfig, TrackerConfig
from skellytracker.core.detectors.keypoint_detectors.mediapipe.mediapipe_model_manager import (
    MediapipePoseModelComplexity,
)
from skellytracker.core.detectors.keypoint_detectors.rtmpose import RTMPoseDetectorConfig
from skellytracker.core.detectors.object_detectors.yolox import YoloxPersonDetectorConfig
from skellytracker.core.sessions.execution_provider_name import ExecutionProviderName
from skellytracker.core.temporal_processing.temporal_processing_config import (
    BBoxPolicyConfig,
    BBoxSmoothingConfig,
    KeypointsWithinBBoxRatioConfig,
)

from skellyforge.post_processing.filters.filter_config import FilterConfig
from freemocap.core.blender.blender_export_config import BlenderExportConfig
from freemocap.core.tasks.triangulation.helpers.triangulation_config import TriangulationConfig
from freemocap.core.tracking.tracker_factory import build_mediapipe_tracker_config



class PosthocMocapPipelineConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    detector_type: Literal["rtmpose", "mediapipe"] = Field(
        default="rtmpose",
        alias="detectorType",
        description="Which pose detector to use: 'rtmpose' (default, more accurate) or 'mediapipe' (faster, CPU-friendly).",
    )
    # RTMPose settings
    rtmpose_model_name: Literal["rtmw-x-l_256x192", "rtmw-x-l_384x288", "rtmw-l-m_256x192"] = Field(
        default="rtmw-x-l_256x192",
        alias="rtmPoseModelName",
        description="RTMPose wholebody model variant. Only used when detector_type='rtmpose'.",
    )
    rtmpose_confidence_threshold: float = Field(
        default=0.004,
        alias="rtmPoseConfidenceThreshold",
        ge=0.0,
        le=1.0,
        description="Keypoint confidence threshold for RTMPose. Only used when detector_type='rtmpose'.",
    )
    execution_provider: ExecutionProviderName | None = Field(
        default=None,
        alias="executionProvider",
        description="ONNX Runtime execution provider for RTMPose. None auto-selects the best available (trt, cuda, coreml, cpu); an explicit choice raises if unavailable.",
    )
    # MediaPipe settings (shared across pose/hands/face detectors)
    mediapipe_model_complexity: MediapipePoseModelComplexity = Field(
        default=MediapipePoseModelComplexity.HEAVY,
        alias="mediapipeModelComplexity",
        description="MediaPipe pose model size. Only used when detector_type='mediapipe'.",
    )
    mediapipe_detection_confidence: float = Field(
        default=0.5,
        alias="mediapipeDetectionConfidence",
        ge=0.0,
        le=1.0,
        description="Minimum detection confidence for all MediaPipe detectors.",
    )
    mediapipe_presence_confidence: float = Field(
        default=0.5,
        alias="mediapipePresenceConfidence",
        ge=0.0,
        le=1.0,
        description="Minimum presence confidence for all MediaPipe detectors.",
    )
    mediapipe_tracking_confidence: float = Field(
        default=0.5,
        alias="mediapipeTrackingConfidence",
        ge=0.0,
        le=1.0,
        description="Minimum tracking confidence for all MediaPipe detectors.",
    )
    mediapipe_num_hands: int = Field(
        default=2,
        alias="mediapipeNumHands",
        ge=1,
        le=4,
        description="Number of hands to detect. Only used when detector_type='mediapipe'.",
    )
    mediapipe_num_faces: int = Field(
        default=1,
        alias="mediapipeNumFaces",
        ge=1,
        le=4,
        description="Number of faces to detect. Only used when detector_type='mediapipe'.",
    )
    video_fps: float = Field(
        default=30.0,
        alias="videoFps",
        gt=0.0,
        description="Frames per second of the recorded video. Used to compute redetect_interval (redetect every 5 s). Set this from cv2.CAP_PROP_FPS before constructing the config for accurate cadence.",
    )
    tracker_config: TrackerConfig | None = Field(default=None)
    calibration_toml_path: str | None = Field(
        default=None,
        alias="calibrationTomlPath",
        description="Path to calibration TOML. If None, the most-recent successful calibration is used.",
    )

    triangulation_config: TriangulationConfig = Field(
        default_factory=TriangulationConfig,
        alias="triangulationConfig",
        description="Configuration for the triangulation step of the mocap pipeline.",
    )

    filter_config: FilterConfig = Field(
        default_factory=FilterConfig,
        alias="filterConfig",
        description="Configuration for the post-processing filter applied to the mocap data.",
    )

    export_to_blender: bool = Field(
        default=True,
        alias="exportToBlender",
        description="If True, export the processed mocap recording to a .blend file after processing.",
    )
    blender_exe_path: str | None = Field(
        default=None,
        alias="blenderExePath",
        description="Path to the Blender executable. If None, auto-detect.",
    )
    auto_open_blend_file: bool = Field(
        default=True,
        alias="autoOpenBlendFile",
        description="If True, open the .blend file in Blender after export completes.",
    )
    blender_export_config: BlenderExportConfig = Field(
        default_factory=BlenderExportConfig,
        alias="blenderExportConfig",
        description="Options forwarded to the Blender addon's 3D model export step. Ignored when export_to_blender=False.",
    )

    @model_validator(mode="after")
    def _build_tracker_config_from_detector_type(self) -> "PosthocMocapPipelineConfig":
        if self.detector_type == "mediapipe":
            self.tracker_config = build_mediapipe_tracker_config(
                model_complexity=self.mediapipe_model_complexity,
                detection_confidence=self.mediapipe_detection_confidence,
                presence_confidence=self.mediapipe_presence_confidence,
                tracking_confidence=self.mediapipe_tracking_confidence,
                num_faces=self.mediapipe_num_faces,
            )
        else:
            redetect_interval = max(1, round(5.0 * self.video_fps))
            self.tracker_config = TrackerConfig(
                stages=[
                    DetectionStageConfig(
                        name="body",
                        object_detector=YoloxPersonDetectorConfig(),
                        keypoint_detectors=[
                            RTMPoseDetectorConfig(
                                model_name=self.rtmpose_model_name,
                                confidence_threshold=self.rtmpose_confidence_threshold,
                            )
                        ],
                        bbox_policy=BBoxPolicyConfig(
                            redetect_interval=redetect_interval,
                            keypoint_bbox_expansion=0.05,
                            fitness_checks=[KeypointsWithinBBoxRatioConfig(threshold=0.5)],
                            min_shrink_ratio_per_frame=0.995,
                            min_bbox_size_px=80.0,
                        ),
                        bbox_smoothing=BBoxSmoothingConfig(alpha=0.4),
                    )
                ]
            )
        return self
