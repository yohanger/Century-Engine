"""
PosthocPipelineManager: lifecycle manager for fire-and-forget posthoc pipelines.

Each posthoc pipeline processes a recorded video group through detection and
a task function (calibration, mocap, etc.), then self-terminates. The processes
log their own errors and report progress via pubsub — the manager just tracks
them for cancellation/shutdown purposes.

Dead pipelines are cleaned up lazily whenever the manager is accessed.
"""
import functools
import logging
import multiprocessing
import multiprocessing.synchronize
from dataclasses import dataclass, field
from multiprocessing.sharedctypes import Synchronized

from skellycam.core.ipc.process_management.worker_registry import WorkerRegistry
from skellycam.core.recorders.videos.recording_info import RecordingInfo

from freemocap.core.pipeline.abcs.pipeline_manager_abc import PipelineManagerABC
from freemocap.core.pipeline.posthoc.pipeline_phases import PosthocPipelineType
from freemocap.core.pipeline.posthoc.posthoc_pipeline import PosthocPipeline
from freemocap.core.tasks.calibration.calibration_task_config import PosthocCalibrationPipelineConfig
from freemocap.core.tasks.calibration.posthoc_calibration_task import run_posthoc_calibration_task
from freemocap.core.tasks.mocap.mocap_task_config import PosthocMocapPipelineConfig
from freemocap.core.tasks.mocap.posthoc_mocap_task import run_posthoc_mocap_aggregator_task
from freemocap.core.types.type_overloads import PipelineIdString
from freemocap.core.pipeline.posthoc.progress_messages import AggregatorNodeProgressMessage, PipelineProgressMessage

logger = logging.getLogger(__name__)


@dataclass
class PosthocPipelineManager(PipelineManagerABC):
    """
    Manages fire-and-forget posthoc pipelines.

    Pipelines self-terminate when processing completes. The manager tracks
    them only for force-shutdown / cancellation. Dead entries are evicted
    lazily on access.
    """

    global_kill_flag: Synchronized
    worker_registry: WorkerRegistry
    lock: multiprocessing.synchronize.Lock = field(default_factory=multiprocessing.Lock)
    pipelines: dict[PipelineIdString, PosthocPipeline] = field(default_factory=dict)
    # Synthetic terminal messages for pipelines stopped manually (via stop_pipeline/
    # stop_all_pipelines), which never emit their own terminal COMPLETE/FAILED message
    # since they're killed rather than left to finish. Drained by get_progress_updates().
    pending_stop_messages: list[PipelineProgressMessage] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Lazy cleanup
    # ------------------------------------------------------------------

    def _evict_dead(self) -> list[PipelineProgressMessage]:
        """Remove pipelines whose processes have all exited. Caller must hold self.lock.

        Drains any remaining progress messages BEFORE closing pubsub so that
        terminal COMPLETE/FAILED messages emitted just before worker exit are
        not lost. Returns those final messages.
        """
        dead_ids: list[PipelineIdString] = [
            pid for pid, pipeline in self.pipelines.items()
            if pipeline.started and not pipeline.alive
        ]
        final_messages: list[PipelineProgressMessage] = []
        for pid in dead_ids:
            pipeline = self.pipelines.pop(pid)
            # Flush relay (pub→sub) THEN drain subscription queues so the
            # terminal COMPLETE/FAILED message emitted just before worker exit
            # is not missed. Without the flush, the relay may not have had a
            # chance to move the message from the publication queue before we
            # read the subscription queue.
            final_messages.extend(pipeline.drain_and_get_messages())
            pipeline.shutdown()
            logger.debug(
                f"Evicted completed PosthocPipeline [{pid}] "
                f"for '{pipeline.recording_info.recording_name}'"
            )
        return final_messages

    def evict_completed(self) -> list[PipelineProgressMessage]:
        """Clean up any posthoc pipelines that have finished running.

        Returns any final progress messages drained from dead pipelines.
        Safe to call frequently — skips lock acquisition when there are no
        pipelines to check.
        """
        if not self.pipelines:
            return []
        with self.lock:
            return self._evict_dead()

    # ------------------------------------------------------------------
    # Pipeline creation
    # ------------------------------------------------------------------

    def create_calibration_pipeline(
        self,
        *,
        recording_info: RecordingInfo,
        calibration_config: PosthocCalibrationPipelineConfig,
    ) -> PosthocPipeline:
        calibration_aggregation_task_fn = functools.partial(
            run_posthoc_calibration_task,
            task_config=calibration_config,
        )
        pipeline = PosthocPipeline.create(
            recording_info=recording_info,
            detector_config=calibration_config.detector_config,
            aggregation_task_fn=calibration_aggregation_task_fn,
            pipeline_type=PosthocPipelineType.CALIBRATION,
            worker_registry=self.worker_registry,
            global_kill_flag=self.global_kill_flag,
        )
        pipeline.queued_progress_message = PipelineProgressMessage(
            pipeline_id=pipeline.id,
            pipeline_type=str(PosthocPipelineType.CALIBRATION),
            phase="queued",
            progress_fraction=0.0,
            detail="Pipeline queued, starting workers...",
            recording_name=recording_info.recording_name,
            recording_path=str(recording_info.full_recording_path),
        )
        pipeline.start()
        with self.lock:
            self._evict_dead()
            self.pipelines[pipeline.id] = pipeline
        logger.info(
            f"Created posthoc calibration pipeline [{pipeline.id}] "
            f"for '{recording_info.recording_name}'"
        )
        return pipeline

    def create_mocap_pipeline(
        self,
        *,
        recording_info: RecordingInfo,
        mocap_config: PosthocMocapPipelineConfig,
        start_pipeline: bool = True,
    ) -> PosthocPipeline:
        mocap_task_fn = functools.partial(
            run_posthoc_mocap_aggregator_task,
            task_config=mocap_config,
        )
        pipeline = PosthocPipeline.create(
            recording_info=recording_info,
            detector_config=mocap_config.tracker_config,
            execution_provider=mocap_config.execution_provider,
            aggregation_task_fn=mocap_task_fn,
            pipeline_type=PosthocPipelineType.MOCAP,
            worker_registry=self.worker_registry,
            global_kill_flag=self.global_kill_flag,
        )
        pipeline.queued_progress_message = PipelineProgressMessage(
            pipeline_id=pipeline.id,
            pipeline_type=str(PosthocPipelineType.MOCAP),
            phase="queued",
            progress_fraction=0.0,
            detail="Pipeline queued, starting workers...",
            recording_name=recording_info.recording_name,
            recording_path=str(recording_info.full_recording_path),
        )
        if start_pipeline:
            pipeline.start()
        with self.lock:
            self._evict_dead()
            self.pipelines[pipeline.id] = pipeline
        logger.info(
            f"Created posthoc mocap pipeline [{pipeline.id}] "
            f"for '{recording_info.recording_name}'"
        )
        return pipeline

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _stopped_by_user_message(self, pipeline: PosthocPipeline) -> AggregatorNodeProgressMessage:
        return AggregatorNodeProgressMessage(
            pipeline_id=pipeline.id,
            pipeline_type=str(pipeline.pipeline_type),
            phase="failed",
            progress_fraction=0.0,
            detail="Stopped by user",
            recording_name=pipeline.recording_info.recording_name,
            recording_path=str(pipeline.recording_info.full_recording_path),
        )

    def stop_pipeline(self, pipeline_id: PipelineIdString) -> bool:
        """Shutdown a single pipeline by ID. Returns True if found, False if not."""
        with self.lock:
            pipeline = self.pipelines.pop(pipeline_id, None)
            if pipeline is not None:
                self.pending_stop_messages.append(self._stopped_by_user_message(pipeline))
        if pipeline is None:
            logger.warning(f"stop_pipeline: pipeline [{pipeline_id}] not found")
            return False
        pipeline.shutdown()
        logger.info(f"Stopped posthoc pipeline [{pipeline_id}]")
        return True

    def stop_all_pipelines(self) -> None:
        """Shutdown all active posthoc pipelines."""
        with self.lock:
            pipelines = list(self.pipelines.values())
            self.pipelines.clear()
            self.pending_stop_messages.extend(
                self._stopped_by_user_message(pipeline) for pipeline in pipelines
            )
        for pipeline in pipelines:
            pipeline.shutdown()
        logger.info(f"Stopped {len(pipelines)} posthoc pipeline(s)")

    def shutdown(self) -> None:
        """Force-shutdown all posthoc pipelines (running or completed).

        Calls shutdown() on every pipeline to release PubSub resources,
        not just alive ones — completed pipelines still hold relay threads
        and multiprocessing.Queue instances until explicitly closed.
        """
        with self.lock:
            for pipeline in self.pipelines.values():
                pipeline.shutdown()
            self.pipelines.clear()
        logger.info("PosthocPipelineManager: all pipelines shut down")

    def get_progress_updates(self) -> list[PipelineProgressMessage]:
        with self.lock:
            stop_messages, self.pending_stop_messages = self.pending_stop_messages, []

        progress_messages: list[PipelineProgressMessage] = list(stop_messages)

        for pipeline in self.pipelines.values():
            progress_messages.extend(pipeline.get_progress_messages())

        return progress_messages
