"""
BaseNode: abstract base for all pipeline nodes (realtime and posthoc).

Encapsulates the common lifecycle pattern shared by every node:
  - A `shutdown_self_flag` (per-node shutdown signal)
  - A `worker` (ManagedWorker wrapping the child process)
  - `start()` / `shutdown()` / `is_alive` lifecycle methods

Subclasses implement a `@classmethod create()` factory that calls
`_create_worker()` to build the ManagedWorker, and a `@staticmethod _run()`
that contains the child-side logic. The `_run()` method receives the
`shutdown_self_flag` as a kwarg and should poll it alongside `ipc.should_continue`
in its main loop.

Error escalation policy (enforced by subclasses, not the base):
  - Posthoc nodes: on exception, call `ipc.shutdown_pipeline()` (pipeline-local)
  - Realtime nodes: on exception, call `ipc.kill_everything()` (app-level)
"""
import dataclasses
import logging
import multiprocessing
import multiprocessing.queues
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from multiprocessing.sharedctypes import Synchronized
from skellycam.core.ipc.process_management.managed_worker import ManagedWorker
from skellycam.core.ipc.process_management.worker_registry import WorkerRegistry

logger = logging.getLogger(__name__)

# TODO - Double check if the below is true, might be nonsense
# On Windows, multiprocessing.spawn causes each child process to
# re-import the full module tree. Spawning many children simultaneously
# creates a file-locking race (PermissionError) because Windows holds
# brief exclusive locks during file reads, and antivirus real-time
# scanning amplifies the contention. Staggering spawns lets each child
# finish its import phase before the next one starts.
_SPAWN_STAGGER_SECONDS: float = 0.25 if sys.platform == "win32" else 0.0

@dataclass
class BaseNode:
    """
    Base class for all pipeline worker nodes.

    Every node owns a ManagedWorker and a per-node shutdown flag.
    The common lifecycle (start / shutdown / is_alive) is implemented here
    so subclasses only need to define `create()` and `_run()`.
    """

    shutdown_self_flag: Synchronized = field(repr=False)
    worker: ManagedWorker = field(repr=False)

    @property
    def is_alive(self) -> bool:
        return self.worker.is_alive()

    def start(self) -> None:
        """Start the child process. Raises if already started."""
        if self.worker.is_alive():
            raise RuntimeError(
                f"{type(self).__name__} worker '{self.worker.name}' is already running"
            )

        if _SPAWN_STAGGER_SECONDS > 0:
            time.sleep(_SPAWN_STAGGER_SECONDS)
        self.worker.start()
        logger.debug(f"{type(self).__name__} worker '{self.worker.name}' started")

    def shutdown(self) -> None:
        """
        Signal the node to stop, then escalate through SIGTERM → SIGKILL.

        Sets the per-node shutdown flag first (so the child's main loop can
        exit cleanly), then delegates to ManagedWorker.terminate_gracefully()
        for escalating force.
        """
        self.shutdown_self_flag.value = True
        self.worker._intentionally_terminated = True
        if self.worker.is_alive():
            logger.debug(f"Shutting down {type(self).__name__} worker '{self.worker.name}'")
            self.worker.terminate_gracefully()
        else:
            self.worker._reap()

        # Subclasses (PosthocAggregationNode, VideoNode, SyncJob, ...) each own a
        # progress/result multiprocessing.Queue shared with their now-dead child
        # process. multiprocessing.Queue registers an untimed atexit finalizer that
        # joins its feeder thread on interpreter shutdown; if that thread is still
        # parked writing to a pipe whose other end (this dead child) never reads it,
        # the join blocks forever -- the process prints pytest's summary but never
        # exits. cancel_join_thread() opts these queues out of that finalizer so we
        # don't wait on it. This can't lose a message the child was still trying to
        # send: by this point worker.terminate_gracefully()/_reap() above already
        # ensured the child process has exited, and whether its own last-gasp
        # message made it onto the pipe was decided by the CHILD's feeder thread
        # before *it* exited -- nothing we do here after the fact changes that.
        for f in dataclasses.fields(self):
            value = getattr(self, f.name, None)
            if hasattr(value, "close") and hasattr(value, "cancel_join_thread"):
                value.close()
                value.cancel_join_thread()

    @staticmethod
    def _create_worker(
        *,
        target: Callable[..., None],
        name: str,
        worker_registry: WorkerRegistry,
        log_queue: multiprocessing.queues.Queue | None,
        kwargs: dict,
        daemon: bool = True,
    ) -> tuple[Synchronized, ManagedWorker]:
        """
        Convenience helper for subclass `create()` methods.

        Creates a shutdown_self_flag + ManagedWorker pair with consistent
        setup. The shutdown_self_flag is automatically injected into kwargs
        so the child _run() receives it.

        Args:
            daemon: Pass False if the child needs to spawn its own child
                processes (e.g. a ProcessPoolExecutor) — Python disallows
                daemonic processes from having children.

        Returns:
            (shutdown_self_flag, worker) tuple for passing to the dataclass constructor.
        """
        shutdown_self_flag: Synchronized = multiprocessing.Value('b', False)
        kwargs["shutdown_self_flag"] = shutdown_self_flag
        worker = worker_registry.create_worker(
            target=target,
            name=name,
            log_queue=log_queue,
            daemon=daemon,
            kwargs=kwargs,
        )
        return shutdown_self_flag, worker
