import json
import logging
import time
import traceback

from fastapi import FastAPI, Request, Response

logger = logging.getLogger(__name__)


def add_middleware(app: FastAPI) -> None:
    logger.debug("Adding middleware...")

    @app.middleware("http")
    async def log_requests(request: Request, call_next) -> Response:
        start_time = time.perf_counter()

        body_bytes = await request.body()
        if body_bytes:
            try:
                parsed = json.loads(body_bytes)
                body_str = json.dumps(parsed, indent=2)
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Not JSON — just decode and show the raw text
                try:
                    body_str = body_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    body_str = f"<binary data, {len(body_bytes)} bytes>"
            received_log = f"Received request: {request.method} {request.url}. Body:\n{body_str}"
        else:
            received_log = f"Received request: {request.method} {request.url}. No body."

        try:
            response: Response = await call_next(request)
            process_time = time.perf_counter() - start_time

            # 425 is used by polling endpoints (e.g. sync-job status) as a deliberate
            # "not ready yet" signal, not a failure — suppress it entirely so it doesn't
            # drown out real logs when the frontend polls every few hundred ms.
            if response.status_code == 425:
                return response

            logger.api(received_log)

            # For error responses, consume the body to log it
            if response.status_code >= 400:
                # Consume the entire response body
                response_body = b""
                async for chunk in response.body_iterator:
                    response_body += chunk

                # Try to decode and log the error
                try:
                    error_content = response_body.decode("utf-8")
                    logger.error(
                        f"Request FAILED: {request.method} {request.url} "
                        f"[{response.status_code}] in {process_time:.6f}s - "
                        f"Error: {error_content}"
                    )
                except UnicodeDecodeError:
                    logger.error(
                        f"Request FAILED: {request.method} {request.url} "
                        f"[{response.status_code}] in {process_time:.6f}s - "
                        f"Error body could not be decoded (length: {len(response_body)} bytes)"
                    )

                # Recreate the response with the consumed body so the client still gets it
                return Response(
                    content=response_body,
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    media_type=response.media_type,
                )
            else:
                logger.api(
                    f"Handled Request: {request.url} processed in {process_time:.6f} seconds "
                    f"and returned status code: {response.status_code}"
                )

            return response

        except Exception as e:
            process_time = time.time() - start_time
            logger.error(
                f"Request EXCEPTION: {request.method} {request.url} "
                f"failed in {process_time:.6f}s with exception: {type(e).__name__}: {str(e)}"
            )
            logger.error(f"Traceback:\n{traceback.format_exc()}")
            raise
