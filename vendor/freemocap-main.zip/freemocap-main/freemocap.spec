# -*- mode: python ; coding: utf-8 -*-

import sys
sys.setrecursionlimit(sys.getrecursionlimit() * 5)

from PyInstaller.utils.hooks import (
    collect_all,
    collect_data_files,
    collect_dynamic_libs,
    collect_submodules,
)
import cv2
import importlib.util
import os
from pathlib import Path

from PyInstaller.building.datastruct import Tree

datas = []
binaries = []
hiddenimports = ["encodings.idna"]

# ── OpenCV ──
binaries.extend(collect_dynamic_libs('cv2'))
hiddenimports.extend(collect_submodules('cv2'))

# ── scipy (targeted: only submodules actually imported at runtime) ──
binaries.extend(collect_dynamic_libs('scipy'))
hiddenimports.extend([
    'scipy.optimize',
    'scipy.sparse',
    'scipy.linalg',
    'scipy.spatial.transform',
    'scipy.interpolate',
    'scipy.cluster.hierarchy',
    'scipy.cluster.vq',
    'scipy.signal',
])

# ── pandas (standard hook handles most; _cyutility missed by default hook) ──
binaries.extend(collect_dynamic_libs('pandas'))
hiddenimports.append('pandas._libs._cyutility')

# ── mediapipe (needs .tflite model files at runtime; only solutions/vision/formats) ──
import mediapipe
mp_path = os.path.dirname(mediapipe.__file__)
datas.append((os.path.join(mp_path, 'modules'), 'mediapipe/modules'))
hiddenimports.extend([
    'mediapipe',
    'mediapipe.python.solutions',
    'mediapipe.python.solutions.holistic',
    'mediapipe.python.solutions.drawing_utils',
    'mediapipe.python.solutions.face_mesh',
    'mediapipe.python.solutions.face_mesh_connections',
    'mediapipe.framework.formats',
    'mediapipe.framework.formats.landmark_pb2',
    'mediapipe.tasks.python',
    'mediapipe.tasks.python.vision',
])

# `mediapipe.tasks.python.core.mediapipe_c_bindings` loads a native shared
# library (libmediapipe.dll/.dylib/.so) out of the `mediapipe.tasks.c`
# package directory via `importlib.resources.files('mediapipe.tasks.c')` at
# runtime. PyInstaller won't discover that binary on its own since it's
# never `import`ed as a normal module — it must be bundled as data so it
# lands next to `tasks/c/__init__.py` in the frozen app, and `tasks.c` must
# be a hiddenimport so the package (and thus its resource location) exists.
mp_tasks_c_path = os.path.join(mp_path, 'tasks', 'c')
if os.path.isdir(mp_tasks_c_path):
    for lib_name in ('libmediapipe.dll', 'libmediapipe.dylib', 'libmediapipe.so'):
        lib_file = os.path.join(mp_tasks_c_path, lib_name)
        if os.path.isfile(lib_file):
            binaries.append((lib_file, 'mediapipe/tasks/c'))
hiddenimports.append('mediapipe.tasks.c')

# ── skellyforge (yaml config files needed at runtime) ──
import skellyforge
sf_path = os.path.dirname(skellyforge.__file__)
datas.append((os.path.join(sf_path, 'skellymodels', 'tracker_info', '*.yaml'), 'skellyforge/skellymodels/tracker_info'))

# ── skellytracker (active trackers only; exclude v1 legacy, tests, scripts) ──
datas.extend(collect_data_files('skellytracker', includes=['**/*.yaml']))
hiddenimports.extend([
    'skellytracker',
    'skellytracker.system',
    'skellytracker.system.logging_configuration',
    'skellytracker.system.logging_configuration.handlers',
    'skellytracker.system.logging_configuration.handlers.websocket_log_queue_handler',
    'skellytracker.io',
    'skellytracker.io.process_videos',
    'skellytracker.io.process_videos.process_single_video',
    'skellytracker.utilities',
    'skellytracker.tracked_object_definition',
    'skellytracker.trackers.mediapipe_tracker',
    'skellytracker.trackers.rtmpose_tracker',
    'skellytracker.trackers.rtmpose_tracker.__rtmpose_tracker',
    'skellytracker.trackers.rtmpose_tracker.run_rtmpose',
    'skellytracker.trackers.charuco_tracker',
    'skellytracker.trackers.brightest_point_tracker',
])

# ── NVIDIA CUDA runtime (bundled so users don't need a system CUDA install) ──
# skellytracker's rtmpose_detector does `find_spec("nvidia")` +
# `nvidia_root.glob("*/bin")` at runtime to discover CUDA libraries.
#
# `onnxruntime_providers_cuda.dll` imports exactly five CUDA libraries. All five
# must be bundled or the provider DLL fails to load, ONNX Runtime silently drops
# CUDAExecutionProvider from its list, and every model runs on CPU (~1-2 fps
# instead of ~20). Verified against the provider DLL's PE import table:
#   cublas64_12.dll + cublaslt64_12.dll  <- nvidia.cublas       (737 MB)
#   cudart64_12.dll                      <- nvidia.cuda_runtime  (11 MB)
#   cudnn64_9.dll                        <- nvidia.cudnn       (1006 MB)
#   cufft64_11.dll                       <- nvidia.cufft        (275 MB)
#
# Excluded — imported by neither the CUDA provider nor its transitive deps:
#   nvidia.cuda_nvrtc   (179 MB) — runtime NVRTC compilation
#   nvidia.nvjitlink     (84 MB) — JIT linker
#
# Skipped entirely for CPU-only builds (`FREEMOCAP_BUILD_VARIANT=cpu`, set by
# the CI matrix's `variant` axis) — those envs never install the `nvidia.*`
# packages in the first place, since `uv sync --extra cpu` pulls
# skellytracker[all-cpu] instead of [all-cuda].
build_variant = os.environ.get('FREEMOCAP_BUILD_VARIANT', 'cuda').lower()
if build_variant == 'cuda':
    for nvidia_subpkg in [
        'nvidia.cublas',
        'nvidia.cuda_runtime',
        'nvidia.cudnn',
        'nvidia.cufft',
    ]:
        try:
            nv_datas, nv_binaries, nv_hidden = collect_all(nvidia_subpkg)
            datas.extend(nv_datas)
            binaries.extend(nv_binaries)
            hiddenimports.extend(nv_hidden)
        except Exception as e:
            print(f"[freemocap.spec] WARNING: could not collect '{nvidia_subpkg}' "
                  f"— GPU acceleration may not work in the frozen build. ({e})")
else:
    print(f"[freemocap.spec] FREEMOCAP_BUILD_VARIANT={build_variant} — "
          f"skipping NVIDIA CUDA runtime bundling (CPU-only build).")

# ── onnxruntime (GPU build — only DLLs + capi bindings; exclude dev tools) ──
binaries.extend(collect_dynamic_libs('onnxruntime'))
hiddenimports.extend(['onnxruntime', 'onnxruntime.capi'])

# ── rtmlib (model registry + configs) ──
rtm_datas, rtm_binaries, rtm_hidden = collect_all('rtmlib')
datas.extend(rtm_datas)
binaries.extend(rtm_binaries)
hiddenimports.extend(rtm_hidden)

# ── onnx (used by rtmpose_session for model loading; separate from onnxruntime) ──
hiddenimports.append('onnx')

# ── setuptools (_vendor only — jaraco, packaging, etc. needed by vendored deps) ──
hiddenimports.extend(collect_submodules('setuptools._vendor'))
jaraco_text_path = os.path.join(
    os.path.dirname(__import__('setuptools', fromlist=['_vendor']).__file__),
    '_vendor', 'jaraco', 'text'
)
datas.append((os.path.join(jaraco_text_path, '*.txt'), 'setuptools/_vendor/jaraco/text/'))

a = Analysis(
    ['freemocap/__main__.py'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # ── Test frameworks ──
        'pytest',
        'pytest_asyncio',
        '_pytest',

        # ── Dev/build tools ──
        'nuitka',
        'ruff',
        'bumpver',
        'pip_tools',
        'poethepoet',
        'pyinstaller',

        # ── Heavy unused modules ──
        'tkinter',
        '_tkinter',
        'IPython',
        'notebook',
        'sphinx',
        'docutils',

        # ── Debug/profile tools ──
        'pdb',
        'cProfile',
        'profile',

        # ── Dependencies in pyproject.toml but never imported ──
        'libsass',
        'sass',
        'sklearn',
        'numpydantic',

        # ── onnxruntime dev tools (not needed at runtime) ──
        'onnxruntime.transformers',
        'onnxruntime.tools',
        'onnxruntime.quantization',
        'onnxruntime.backend',
        'onnxruntime.datasets',

        # ── mediapipe dev/bundled tools ──
        'mediapipe.tasks.python.test',
        'mediapipe.tasks.python.metadata',
        'mediapipe.tasks.python.benchmark',

        # ── skellytracker legacy/unused ──
        'skellytracker.tests',
        'skellytracker.trackers.v1',
        'skellytracker.trackers.vitpose_tracker',
        'skellytracker.trackers.legacy_mediapipe_tracker',
        'skellytracker.scripts',
        'skellytracker.__main__',

        # ── setuptools cruft ──
        'setuptools.tests',
        'setuptools.command',
        'setuptools._distutils.command',
        'setuptools._distutils.tests',
    ],
    noarchive=False,
)

# ── Blender export resources ──
# Blender executes this script using Blender's own Python interpreter. It must
# therefore exist as a real source file outside PyInstaller's embedded archive.
blender_export_script = os.path.join(
    SPECPATH,
    "freemocap",
    "core",
    "blender",
    "helpers",
    "run_blender_export.py",
)

if not os.path.isfile(blender_export_script):
    raise FileNotFoundError(
        f"Blender export script not found: {blender_export_script}"
    )

a.datas.append(
    (
        "freemocap/core/blender/helpers/run_blender_export.py",
        blender_export_script,
        "DATA",
    )
)

# Blender also needs the add-on as loose Python source files because Blender's
# Python interpreter cannot import it from PyInstaller's embedded PYZ archive.
blender_addon_spec = importlib.util.find_spec("freemocap_blender_addon")

if (
    blender_addon_spec is None
    or blender_addon_spec.submodule_search_locations is None
):
    raise ModuleNotFoundError(
        "Could not locate installed package: freemocap_blender_addon"
    )

blender_addon_source = Path(
    next(iter(blender_addon_spec.submodule_search_locations))
).resolve()

print(
    "[freemocap.spec] Bundling Blender add-on source from:",
    blender_addon_source,
)

a.datas += Tree(
    str(blender_addon_source),
    prefix="freemocap_blender_addon",
)

pyz = PYZ(a.pure, a.zipped_data)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='freemocap_server',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=['nvcuda', 'nvrtc', 'cudnn', 'cublas', 'cufft', 'cudart'],
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=['nvcuda', 'nvrtc', 'cudnn', 'cublas', 'cufft', 'cudart'],
    name='freemocap_server',
)
