---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE REQUEST]"
labels: feature
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**What is the use case for this feature?**
For example, will it help with your scientific data collection or make animating characters from the data easier?

**Additional context**
Add any other context or screenshots about the feature request here.
